var canvas;
async function Boot()
{
    // J'initialise le réseau avec lequel je vais communiqué
    InitEthereumNetwork();
    InitTezosNetwork();
    
    // Ici je vais utilisé le testnet jakartanet
    SwitchToTezosNetwork("jakartanet");
    canvas = CreateCanvas(0,0,window.innerWidth,window.innerHeight);
    Code();
    
}
async function Code()
{
    var hauteur = await Network.GetBlockchainLength()
    await Network.LoadBlockAtIndex(hauteur)
    var hash = Network.GetBlockHash()
    var horodatage = Network.GetBlockTimeStamp()
    var lerp = LerpHash(hash)
    var nombres = B58mux32(hash)
    
}





