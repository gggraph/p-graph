function Boot()
{
    InitTezosNetwork();
    setInterval(TestLoop, 1000);
    
}

async function TestLoop()
{
}